# Binance tss-lib Jetstream VM Completion — Final Summary

This folder contains the final RSS-enabled summary CSVs for the Binance tss-lib Jetstream VM benchmark runs.

Final repeat trial root:

- `/home/exouser/socioty-results/tss-lib/repeat-trials/rss-repeat-20260711-043544`

Included summary CSVs:

- `base_matrix_trial01.with_rss.csv`
- `base_matrix_trial02.with_rss.csv`
- `multisign_fixed_trial01.with_rss.csv`
- `multisign_fixed_trial02.with_rss.csv`
- `multisign_random_trial01.with_rss.csv`
- `multisign_random_trial02.with_rss.csv`

Metrics include:

- runtime
- message counts
- message bytes
- verification status
- signer sets for multisign
- keygen RSS
- signing RSS
- overall max RSS per party

Raw artifacts remain under `/home/exouser/socioty-results/tss-lib/`.

Important: raw keygen artifacts include `keygen_save_party_*.json`, which are private keyshare files. Keep the full backup private and do not commit or share those files publicly.
